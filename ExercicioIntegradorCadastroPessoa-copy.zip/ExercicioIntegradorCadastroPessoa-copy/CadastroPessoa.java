
/**
 * Escreva uma descrição da classe CadastroPessoa aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class CadastroPessoa
{
    private Pessoa vetorPessoa[];
    
    private int index;  
    
    public CadastroPessoa (int tam){
        this.vetorPessoa = new Pessoa[tam];
        this.index = 0;
    }
    
    public boolean addPessoa(Pessoa pessoa){
        if(this.index < vetorPessoa.length){
            vetorPessoa[this.index] = pessoa;
            this.index++;
            return true;
        }
        return false;
    }
       
   public int buscarPessoa (int codigo){
       for(int i = 0; i < this.index; i++){
           if(this.vetorPessoa[i].getCodigo() == codigo){
               return i;
           }
       }
       return -1;
   }
   
   public void mostraVetor(){
       for(int i = 0; i < this.index; i++){
           System.out.println(this.vetorPessoa[i]);
       }
   }
   
   public int superSalario(){
       int qtde = 0;
       
       for(int i = 0; i < this.index; i++){
           if(this.vetorPessoa[i].getSalario() > 30000){
               qtde++;
           }
       }
       return qtde;
   }
   
   public double maiorSalario(){
       double maior = vetorPessoa[0].getSalario();
       for(int i = 1; i < this.index; i++){
           if(this.vetorPessoa[i].getSalario() > maior){
               maior = vetorPessoa[i].getSalario();
           }
       }
       return maior;
   }
}