
/**
 * Escreva uma descrição da classe CadastroPessoa aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class Pessoa
{
    private String nome;
    private int codigo;
    private double salario;
    
    public Pessoa()
    {
        // inicializa variáveis de instância
        this.nome = null;
        this.codigo = 0;
        this.salario = 0;
        
    }

    public void setNome (String nome){
        this.nome = nome;
    }
    
    public void setCodigo (int codigo){
        this.codigo = codigo;
    }
    
    public void setSalario (double salario){
        this.salario = salario;
    }
    
    public String getNome(){
        return this.nome;
    }
    
    public int getCodigo(){
        return this.codigo;
    }
    
    public double getSalario(){
        return this.salario;
    }
    
    public String toString(){
        return "Nome" +nome+ " ,codigo" +codigo+ " ,salario" +salario;
    }
    
}