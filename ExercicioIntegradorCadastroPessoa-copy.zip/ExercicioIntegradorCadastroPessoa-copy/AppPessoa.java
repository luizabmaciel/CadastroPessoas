import java.util.Scanner;

public class AppPessoa {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        // Cria o cadastro com 5 posições
        CadastroPessoa cadastro = new CadastroPessoa(5);

        // Inserir 5 pessoas
        for (int i = 0; i < 5; i++) {
            System.out.println("\n--- Cadastro da Pessoa " + (i + 1) + " ---");

            System.out.print("Nome: ");
            String nome = teclado.nextLine();

            System.out.print("Código: ");
            int codigo = teclado.nextInt();

            System.out.print("Salário: ");
            double salario = teclado.nextDouble();
            teclado.nextLine(); // limpar buffer

            // Criar e preencher objeto Pessoa
            Pessoa p = new Pessoa();
            p.setNome(nome);
            p.setCodigo(codigo);
            p.setSalario(salario);

            // Adicionar no cadastro
            boolean inseriu = cadastro.addPessoa(p);

            if (!inseriu) {
                System.out.println("⚠️ Não foi possível inserir. Vetor cheio!");
                break;
            }
        }

        // Mostrar todas as pessoas
        System.out.println("\n===== Pessoas Cadastradas =====");
        cadastro.mostraVetor();

        // Buscar uma pessoa pelo código
        System.out.print("\nDigite o código da pessoa para buscar posição: ");
        int codBusca = teclado.nextInt();
        int pos = cadastro.buscarPessoa(codBusca);

        if (pos != -1) {
            System.out.println("Pessoa encontrada na posição: " + pos);
        } else {
            System.out.println("Pessoa não encontrada.");
        }

        // Mostrar quantidade de supersalários
        System.out.println("\nQuantidade de supersalários (> 30000): " + cadastro.superSalario());

        // Mostrar maior salário
        System.out.println("Maior salário: " + cadastro.maiorSalario());

        teclado.close();
    }
}